$(window).load(function() {
	
	$("#add_songs").hide();
	var	savingDataToArray=[];
	var object="";

	$("#AddSongsInList").click(function(){
		
	$("#Songs_List").hide();
	$("#add_songs").show();	
	});

	$("#SongList").click(function(){
		
	$("#Songs_List").show();
	$("#add_songs").hide();	
	});
	
	$("#submit").click(function(){
	var songname=$("#SName").val();
	var Artist=$("#Artist").val();
	 var Album=$("#Album").val();

	var object={
				"song":songname,
				"art":Artist,
				"alb":Album
			}

	

	
savingDataToArray.push(object);


	if(localStorage.getItem('SongsData')==null)
	{
		localStorage.setItem('SongsData', JSON.stringify(savingDataToArray));	
	}
	else
		{
			 var b="";
			var b=JSON.parse(localStorage.getItem('SongsData'));
			 
			 b.push(object);
			 
			 localStorage.setItem('SongsData', JSON.stringify(b));
}

	
});

	var fetchingDataFromLocal=JSON.parse(localStorage.getItem('SongsData'));
	
	$.each(fetchingDataFromLocal,function(key,value){
	$('<tr>').attr("class","Row").append
	($('<td>').text(value.song)).append($('<td>').text(value.art)).append
	($('<td>').text(value.alb)).appendTo("#myTable");
    
    $('<option>').text(value.art).appendTo("#ArtSelect");
     $('<option>').text(value.alb).appendTo("#AlbSelect");
	
	 });

	// sorting
		function sortTable(table, order) {
    var asc   = order === 'asc',
        tbody = table.find('tbody');

    tbody.find('tr').sort(function(a, b) {
        if (asc) {
            return $('td:nth-child(3)', a).text().localeCompare($('td:nth-child(3)', b).text());
        } else {
            return $('td:nth-child(3)', b).text().localeCompare($('td:nth-child(3)', a).text());
        }
    }).appendTo(tbody);
}

	//sorting
	$('#nameAsc').click(function(){

    sortTable($('#myTable'),'asc');
	});
	$('#nameDesc').click(function(){

    sortTable($('#myTable'),'desc');
	});
// Search
	$("#Search").blur(function(){

			$.each(fetchingDataFromLocal,function(key,value){
			if($("#Search").val()===value.song)
			{
$('.Row').empty();
	$('<tr>').append
	($('<td>').text(value.song)).append($('<td>').text(value.art)).append
	($('<td>').text(value.alb)).appendTo("#myTable");
			}
			
			});

	});

	//Search

	$("#ArtSelect").change(function(){

		$.each(fetchingDataFromLocal,function(key,value){
			if($("#ArtSelect").val()===value.art)
			{
	$('.Row').empty();
	$('<tr>').attr("class","Row").append
	($('<td>').text(value.song)).append($('<td>').text(value.art)).append
	($('<td>').text(value.alb)).appendTo("#myTable");
			}
			
			});

	});

	$("#AlbSelect").change(function(){

		$.each(fetchingDataFromLocal,function(key,value){
			if($("#AlbSelect").val()===value.alb)
			{
	$('.Row').empty();
	$('<tr>').attr("class","Row").append
	($('<td>').text(value.song)).append($('<td>').text(value.art)).append
	($('<td>').text(value.alb)).appendTo("#myTable");
			}
			
			});

	});
});