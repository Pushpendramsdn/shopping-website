$(window).load(function(){
		
	var count=0;
	$.ajax(
	 	{
	 		url: "common/questions.json", 
	 		success: function(result){
      		var jsonData=result;
      		addRow(jsonData);
	 		}
        
	});

	function addRow(jsonData) {
		// Adding question
	 	$.each(jsonData,function(key,value){
	$("<div>").attr("class","col-md-12").attr("id","container").append($("<div>").attr("class","col-md-12").attr("id","question"+key).append($("<h1>").text(value.question)))
	.appendTo("#wrapper");
		addOpt(value.options,key);


function addOpt(radioOptions,index){
// Adding Options
		$.each(radioOptions,function(i,opt){

				$("<div>").attr("class","col-md-3").attr("id","options").append(

			 $('<input />', { 
                type: 'radio', 
                name: index+'radio', 
              	value: opt
            })
			 ).append(opt).appendTo("#question"+index);

});
}//adding options ends
});//end of each
	 	 
	 	
	 		$('input[type="radio"]').click(function(){
	 			var val=this.value;
	 			$.each(jsonData,function(key,value){
				console.log(value.answer);

	 			if(value.answer == val){
	 				count++;
	 			} 

	 		});//end of each
	 			// alert("your score is"+count);

	 		});//end of click
	

	 	

} 
$("<div>").attr("class","col-md-12").attr("id","submit").append(

		$("<input>").attr("type","button").attr("value","submit").attr("id","submitbtn")

	)
	.appendTo("#wrapper");

	$("#submitbtn").click(function(){
alert(count);
	});

	 

});//document ready

