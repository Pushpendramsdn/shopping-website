$(window).load(function(){

		
	
		
	
	$.ajax(
	 	{
	 		url: "js/data.json", 
	 		success: function(result){
      		var jsonData=result;
      		addRow(jsonData);
	 		}
        
	});

	function addRow(jsonData) {
		$.each(jsonData,function(key,value){
		$("<div>").attr("class","container").append(
			$("<div>").attr("class","HotelName").append($("<a>").attr("href","#").attr("id","Hname"+key).append(value.name)),
			$("<div>").attr("class","Rating").attr("id","rating"+key),
			$("<div>").attr("class","clear"),
			$("<div>").attr("class","Location").append($("<h1>").append(value.address)),
			$("<div>").attr("class","Price").attr("id","price"+key)
			).appendTo(".wrapper");
		addRating(value.rating,key);
		addPrice(value.price,key);
		popUpShow(key);
		
// Adding Rating
			function addRating(x,y){

				for(var i=0;i<x;i++)
				{
					$("<span>").append("&#9733;").appendTo("#rating"+y);
				}
			}
// Adding Price	
			function addPrice(x,y){

				for(var i=0;i<x;i++)
				{
					$("<span>").append("$").appendTo("#price"+y);
				}
			}		

		});
//PopUP show


	function popUpShow(index){
		var a="";
		var b="";
	$("#Hname"+index).click(function(){

		$.each(jsonData,function(key,value){

			if(index==key){
					a=value.name;
					b=value.description;

				
			}
		});

		$("<div>").append($("<span>").text(a),
			$("<div>").append($("<span>").text(b))
			).appendTo(".popUpBox")
		$(".popUpBox").css("display", "inherit");
		$(".wrapper").css("opacity",0.4);

		$(document.body).mousedown(function(){
			 window.location = "";
 			
		});

		// alert("clicked"+index)
	});
 }	//end of popUpShow
} 


});//document ready

