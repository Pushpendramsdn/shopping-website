$(window).load(function() {
	
	$("#add_songs").hide();
	var	savingDataToArray=[];
	var object="";

	$("#AddSongsInList").click(function(){
		
	$("#Songs_List").hide();
	$("#add_songs").show();	
	});

	$("#SongList").click(function(){
		
		
	$("#Songs_List").show();
	$("#add_songs").hide();	
	});
	// --------------------------------------------

// 		$('#rating_star').bind('click', function() {
//     alert($(this).attr('id'));
// });

$('#rating_star').bind('click', function(event) {
    var rating_value=$(event.target).attr('id');
    $('#rating_star').empty();
    for(var i=1;i<=rating_value;i++)
    {
    	$("<span>").html("&#9733;").appendTo('#rating_star');
    }
     for(var i=1;i<5-rating_value;i++)
    {
    	$("<span>").html("&#9734;").appendTo('#rating_star');
    }
    sendingRatingToSubmit(rating_value);
});
	// ---------------------------------------------
	

 function sendingRatingToSubmit(i){

 	var songname=$("#SName").val();
	var Artist=$("#Artist").val();
	 var Album=$("#Album").val();
	 if(i===null)
	 {
	 	var Rating=0;
	 }
	 else{
	 var Rating=i;
}
 	$("#submit").click(function(){
	 alert(Rating);
	var object={
				"song":songname,
				"art":Artist,
				"alb":Album,
				"rating":Rating
				
			}

	

	
savingDataToArray.push(object);


	if(localStorage.getItem('SongsData')==null)
	{
		localStorage.setItem('SongsData', JSON.stringify(savingDataToArray));	
	}
	else
		{
			 var b="";
			var b=JSON.parse(localStorage.getItem('SongsData'));
			 
			 b.push(object);
			 
			 localStorage.setItem('SongsData', JSON.stringify(b));
}
});

}//end of sending value to submit
	


	var fetchingDataFromLocal=JSON.parse(localStorage.getItem('SongsData'));
	
	$.each(fetchingDataFromLocal,function(key,value){
	$('<tr>').attr("class","Row").append(
	$('<td>').text(value.song),$('<td>').text(value.art),$('<td>').text(value.alb),$('<td>').attr("id","starRating"+key)).appendTo("#myTable");
    AddingStarInRating(key,value.rating);
 // -----------------------------


 
 // -----------------------------  
    
if(value.art.indexOf("#ArtSelect")<0){
 $('<option>').text(value.art).appendTo("#ArtSelect");

}
if(value.art.indexOf("#AlbSelect")<0){
 $('<option>').text(value.alb).appendTo("#AlbSelect");
}
     function AddingStarInRating(index,starCount)
     {
     	
     	 for(var i=1;i<=starCount;i++)
    {
    	$("<span>").html("&#9733;").appendTo('#starRating'+index);
    }
     for(var i=1;i<=5-starCount;i++)
    {
    	$("<span>").html("&#9734;").appendTo('#starRating'+index);
    }
     	
      }// end of AddingStarInRating
	
	 });

	// sorting
		function sortTable(table, order) {
    var asc   = order === 'asc',
        tbody = table.find('tbody');

    tbody.find('tr').sort(function(a, b) {
        if (asc) {
            return $('td:nth-child(3)', a).text().localeCompare($('td:nth-child(3)', b).text());
        } else {
            return $('td:nth-child(3)', b).text().localeCompare($('td:nth-child(3)', a).text());
        }
    }).appendTo(tbody);
}

	//sorting
	$('#nameAsc').click(function(){

    sortTable($('#myTable'),'asc');
	});
	$('#nameDesc').click(function(){

    sortTable($('#myTable'),'desc');
	});
// Search
	$("#Search").blur(function(){

			$.each(fetchingDataFromLocal,function(key,value){
			if($("#Search").val()===value.song)
			{
$('.Row').empty();
	$('<tr>').append
	($('<td>').text(value.song)).append($('<td>').text(value.art)).append
	($('<td>').text(value.alb)).appendTo("#myTable");
			}
			
			});

	});

	//Search

	$("#ArtSelect").change(function(){

		$.each(fetchingDataFromLocal,function(key,value){
			if($("#ArtSelect").val()===value.art)
			{
	$('.Row').empty();
	$('<tr>').attr("class","Row").append
	($('<td>').text(value.song)).append($('<td>').text(value.art)).append
	($('<td>').text(value.alb)).appendTo("#myTable");
			}
			
			});

	});

	$("#AlbSelect").change(function(){

		$.each(fetchingDataFromLocal,function(key,value){
			if($("#AlbSelect").val()===value.alb)
			{
	$('.Row').empty();
	$('<tr>').attr("class","Row").append
	($('<td>').text(value.song)).append($('<td>').text(value.art)).append
	($('<td>').text(value.alb)).appendTo("#myTable");
			}
			
			});

	});
});